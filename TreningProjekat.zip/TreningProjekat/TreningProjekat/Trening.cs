﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TreningProjekat
{

    abstract public class Trening
    {
        private string naziv;
        private int brojSetova;
        private int trajanje;
        public string Naziv
        {
            get { return naziv; }
            set { naziv = value; }

        }

        public int BrojSetova
        {
            get { return brojSetova; }
            set { brojSetova = value; }
        }

        public int Trajanje
        {
            get { return trajanje; }
            set
            {
                if (value <= 0)
                    throw new Exception("Trajanje mora biti veće od 0!");
                trajanje = value;
            }
        }


        public Trening(string naziv, int brojSetova, int trajanje)
        {
            this.Naziv = naziv;
            this.BrojSetova = brojSetova;
            this.Trajanje = trajanje;
        }
        public abstract string Opis();
    }

   public class KardioTrening : Trening
    {
        public KardioTrening(string naziv, int trajanje):base (naziv, 1, trajanje)
        { 

        }

        public override string Opis()
        {
            return "Kardio: " + Naziv + ", trajanje: " + Trajanje + " min";
        }
    }

    public class SnagaTrening : Trening
    {
        public SnagaTrening(string naziv, int brojSetova, int trajanje)
            : base(naziv, brojSetova, trajanje) { }

        public override string Opis()
        {
            return "Snaga: " + Naziv + ", Setova: " + BrojSetova + ", Trajanje: " + Trajanje + " min";
        }
    }

    public class TreningZaMrsavljenje : Trening
    {
        public TreningZaMrsavljenje(string naziv, int trajanje)
            : base(naziv, 2, trajanje) { }

        public override string Opis()
        {
            return "Mršavljenje: " + Naziv + ", Trajanje: " + Trajanje + " min";
        }
    }



}
