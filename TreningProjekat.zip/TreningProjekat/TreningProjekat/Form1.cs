﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TreningProjekat
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            List<Trening> treninzi = new List<Trening>();

            if (radioButton1.Checked)
            {
                treninzi.Add(new KardioTrening("Trčanje", 30));
                treninzi.Add(new KardioTrening("Veslanje", 25));
                treninzi.Add(new KardioTrening("Vožnja bicikla", 40));
            }
            else if (radioButton2.Checked)
            {
                treninzi.Add(new SnagaTrening("Bench Press", 4, 20));
                treninzi.Add(new SnagaTrening("Čučnjevi", 3, 15));
                treninzi.Add(new SnagaTrening("Mrtvo dizanje", 3, 25));
            }
            else if (radioButton3.Checked)
            {
                treninzi.Add(new TreningZaMrsavljenje("Stepenice", 30));
                treninzi.Add(new TreningZaMrsavljenje("Brzi hod", 40));
                treninzi.Add(new TreningZaMrsavljenje("Preskakanje konopca", 20));
            }

            //listBox1.Items.Clear();

            for (int i = 0; i < treninzi.Count; i++)
            {
                listBox1.Items.Add(treninzi[i].Opis());
            }
            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                listBox1.Items.Add(listBox2.Items[i]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
        int i = 0;
        List<String> l = new List<String>();
        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();              
            string unos = textBox1.Text;        
            l.Add(unos);                         

            for (int j = 0; j < l.Count; j++)    
            {
                listBox2.Items.Add(l[j]);
            }

            StreamWriter f = new StreamWriter("plan.txt");
            f.WriteLine("plan.txt");
            f.Close();
            textBox1.Clear();
        }
    }
}

